function updateDateTime() {
  const now = new Date();

  const element = document.getElementById("datetime");

  if (!element) return; // prevents crashes

  element.textContent =
    now.toLocaleDateString() + " | " + now.toLocaleTimeString();
}

updateDateTime();
setInterval(updateDateTime, 1000);